from django.apps import AppConfig


class CatConfig(AppConfig):
    name = 'cat'
